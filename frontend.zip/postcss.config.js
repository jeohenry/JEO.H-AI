// postcss.config.js
module.exports = {
  plugins: [
    require('tailwindcss'),
    require('autoprefixer'),
    // Add other plugins below as needed
    // require('postcss-nested'),
    // require('postcss-custom-properties'),
  ],
};




